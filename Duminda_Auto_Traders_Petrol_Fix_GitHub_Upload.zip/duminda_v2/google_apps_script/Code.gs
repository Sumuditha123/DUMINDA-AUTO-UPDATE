/**
 * Duminda Auto Traders - Petrol Sheet receiver
 * Deploy as Web App: Execute as Me; access: Anyone.
 * Change SHARED_TOKEN to the same long random value used in petrol_screen.dart.
 */
const SPREADSHEET_ID = '1cGWjHXmXI5h3RW2obRsBnwUiy948DtfKkxxdNWHSXLA';
const SHEET_NAME = 'Petrol';
const SHARED_TOKEN = 'CHANGE_THIS_TO_A_LONG_RANDOM_SECRET';

function doPost(e) {
  try {
    const body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    if (!body.token || body.token !== SHARED_TOKEN) {
      return jsonResponse({ ok: false, error: 'Unauthorized request' });
    }

    const required = ['dateTime', 'repNum', 'repName', 'stationName', 'litres'];
    for (const key of required) {
      if (body[key] === undefined || body[key] === null || String(body[key]).trim() === '') {
        return jsonResponse({ ok: false, error: 'Missing field: ' + key });
      }
    }

    const litres = Number(body.litres);
    if (!Number.isFinite(litres) || litres <= 0) {
      return jsonResponse({ ok: false, error: 'Invalid petrol litres' });
    }

    const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
    const sheet = ss.getSheetByName(SHEET_NAME);
    if (!sheet) throw new Error('Sheet tab "' + SHEET_NAME + '" was not found.');

    // Sheet columns: A Date & Time, B Rep Num, C Rep Name,
    // D Petrol Station Name, E Petrol (L), F Link, G Remarks, H Sri Lanka Format.
    sheet.appendRow([
      body.dateTime,
      String(body.repNum),
      String(body.repName),
      String(body.stationName),
      litres,
      String(body.photoLink || ''),
      String(body.remarks || ''),
      String(body.sriLankaTime || body.dateTime)
    ]);

    return jsonResponse({ ok: true, message: 'Petrol record added' });
  } catch (err) {
    return jsonResponse({ ok: false, error: String(err && err.message ? err.message : err) });
  }
}

function doGet() {
  return jsonResponse({ ok: true, service: 'Duminda Auto Traders Petrol Sheet API' });
}

function jsonResponse(data) {
  return ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}
