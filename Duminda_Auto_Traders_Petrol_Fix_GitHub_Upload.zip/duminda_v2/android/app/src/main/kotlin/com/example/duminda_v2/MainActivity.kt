package com.example.duminda_v2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
