import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import '../../theme/app_theme.dart';

class AdminAttendanceView extends StatelessWidget {
  const AdminAttendanceView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('All Attendance')),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('attendance')
            .orderBy('createdAt', descending: true)
            .snapshots(),
        builder: (ctx, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final docs = snap.data?.docs ?? [];
          if (docs.isEmpty) {
            return const Center(
                child: Text('No records yet.',
                    style: TextStyle(color: AppTheme.textGrey)));
          }
          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: docs.length,
            itemBuilder: (_, i) {
              final d = docs[i].data() as Map<String, dynamic>;
              final checkIn = d['checkIn'];
              final checkOut = d['checkOut'];
              return Card(
                margin: const EdgeInsets.only(bottom: 10),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.calendar_today_rounded,
                              size: 16, color: AppTheme.primary),
                          const SizedBox(width: 6),
                          Text(d['date'] ?? '',
                              style: const TextStyle(
                                  fontWeight: FontWeight.w700)),
                          const Spacer(),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 2),
                            decoration: BoxDecoration(
                              color: checkOut != null
                                  ? Colors.green.shade50
                                  : Colors.orange.shade50,
                              borderRadius:
                              BorderRadius.circular(20),
                            ),
                            child: Text(
                              checkOut != null
                                  ? 'Complete'
                                  : 'Checked In',
                              style: TextStyle(
                                  fontSize: 11,
                                  color: checkOut != null
                                      ? Colors.green
                                      : Colors.orange,
                                  fontWeight: FontWeight.w600),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      if (checkIn != null)
                        Row(
                          children: [
                            const Icon(Icons.login_rounded,
                                size: 14, color: Colors.green),
                            const SizedBox(width: 4),
                            Text(
                              'IN: ${DateFormat('hh:mm a').format(DateTime.parse(checkIn['time']))}',
                              style: const TextStyle(
                                  fontSize: 12,
                                  color: AppTheme.textGrey),
                            ),
                            const SizedBox(width: 8),
                            const Icon(Icons.location_on_rounded,
                                size: 12, color: Colors.grey),
                            const SizedBox(width: 2),
                            Text(
                              '${checkIn['lat']?.toStringAsFixed(4)}, ${checkIn['lng']?.toStringAsFixed(4)}',
                              style: const TextStyle(
                                  fontSize: 11,
                                  color: AppTheme.textGrey),
                            ),
                          ],
                        ),
                      const SizedBox(height: 4),
                      if (checkOut != null)
                        Row(
                          children: [
                            const Icon(Icons.logout_rounded,
                                size: 14, color: Colors.orange),
                            const SizedBox(width: 4),
                            Text(
                              'OUT: ${DateFormat('hh:mm a').format(DateTime.parse(checkOut['time']))}',
                              style: const TextStyle(
                                  fontSize: 12,
                                  color: AppTheme.textGrey),
                            ),
                            const SizedBox(width: 8),
                            const Icon(Icons.location_on_rounded,
                                size: 12, color: Colors.grey),
                            const SizedBox(width: 2),
                            Text(
                              '${checkOut['lat']?.toStringAsFixed(4)}, ${checkOut['lng']?.toStringAsFixed(4)}',
                              style: const TextStyle(
                                  fontSize: 11,
                                  color: AppTheme.textGrey),
                            ),
                          ],
                        ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}