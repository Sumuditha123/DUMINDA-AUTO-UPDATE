import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../theme/app_theme.dart';
import '../login_screen.dart';
import 'admin_attendance_view.dart';
import 'admin_petrol_view.dart';
import 'admin_customers_view.dart';
import 'admin_visits_view.dart';

class AdminHome extends StatefulWidget {
  const AdminHome({super.key});

  @override
  State<AdminHome> createState() => _AdminHomeState();
}

class _AdminHomeState extends State<AdminHome> {
  String _adminName = '';
  Map<String, int> _counts = {
    'users': 0,
    'attendance': 0,
    'petrol': 0,
    'customers': 0,
  };

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid != null) {
      final doc = await FirebaseFirestore.instance
          .collection('users')
          .doc(uid)
          .get();
      setState(() => _adminName = doc.data()?['name'] ?? 'Admin');
    }

    final collections = ['users', 'attendance', 'petrol', 'customers'];
    for (final col in collections) {
      final snap = await FirebaseFirestore.instance
          .collection(col)
          .count()
          .get();
      setState(() => _counts[col] = snap.count ?? 0);
    }
  }

  void _logout() async {
    await FirebaseAuth.instance.signOut();
    if (mounted) {
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (_) => const LoginScreen()));
    }
  }

  @override
  Widget build(BuildContext context) {
    final List<_AdminCard> cards = [
      _AdminCard(
          icon: Icons.access_time_rounded,
          label: 'Attendance',
          count: _counts['attendance']!,
          color: const Color(0xFF6366F1),
          screen: const AdminAttendanceView()),
      _AdminCard(
          icon: Icons.local_gas_station_rounded,
          label: 'Petrol Claims',
          count: _counts['petrol']!,
          color: const Color(0xFFF59E0B),
          screen: const AdminPetrolView()),
      _AdminCard(
          icon: Icons.people_rounded,
          label: 'Customers',
          count: _counts['customers']!,
          color: const Color(0xFF10B981),
          screen: const AdminCustomersView()),
      _AdminCard(
          icon: Icons.map_rounded,
          label: 'Visits',
          count: 0,
          color: const Color(0xFFEF4444),
          screen: const AdminVisitsView()),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Panel'),
        actions: [
          IconButton(
              icon: const Icon(Icons.logout_rounded),
              onPressed: _logout),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.indigo.shade700,
                      Colors.indigo.shade500
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Row(
                  children: [
                    const CircleAvatar(
                      backgroundColor: Colors.white24,
                      radius: 26,
                      child: Icon(
                          Icons.admin_panel_settings_rounded,
                          color: Colors.white,
                          size: 26),
                    ),
                    const SizedBox(width: 14),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Hello, $_adminName',
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.bold)),
                        Text('${_counts['users']} users registered',
                            style: const TextStyle(
                                color: Colors.white70,
                                fontSize: 12)),
                      ],
                    )
                  ],
                ),
              ),
              const SizedBox(height: 28),
              const Text('Dashboard',
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: AppTheme.textDark)),
              const SizedBox(height: 14),
              Expanded(
                child: GridView.count(
                  crossAxisCount: 2,
                  crossAxisSpacing: 14,
                  mainAxisSpacing: 14,
                  children: cards
                      .map((c) => _buildCard(context, c))
                      .toList(),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCard(BuildContext context, _AdminCard c) {
    return GestureDetector(
      onTap: () => Navigator.push(
          context, MaterialPageRoute(builder: (_) => c.screen)),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
                color: c.color.withOpacity(0.15),
                blurRadius: 12,
                offset: const Offset(0, 4))
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                color: c.color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Icon(c.icon, color: c.color, size: 30),
            ),
            const SizedBox(height: 12),
            Text(c.label,
                style: const TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 14,
                    color: AppTheme.textDark)),
            const SizedBox(height: 4),
            Text('${c.count} records',
                style: const TextStyle(
                    fontSize: 12, color: AppTheme.textGrey)),
          ],
        ),
      ),
    );
  }
}

class _AdminCard {
  final IconData icon;
  final String label;
  final int count;
  final Color color;
  final Widget screen;
  _AdminCard({
    required this.icon,
    required this.label,
    required this.count,
    required this.color,
    required this.screen,
  });
}