import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../theme/app_theme.dart';

// ─── Customers View ──────────────────────────────────────────────────────────
class AdminCustomersView extends StatelessWidget {
  const AdminCustomersView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('All Customers')),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('customers')
            .orderBy('createdAt', descending: true)
            .snapshots(),
        builder: (ctx, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final docs = snap.data?.docs ?? [];
          if (docs.isEmpty) {
            return const Center(
                child: Text('No customers registered.',
                    style: TextStyle(color: AppTheme.textGrey)));
          }
          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: docs.length,
            itemBuilder: (_, i) {
              final d = docs[i].data() as Map<String, dynamic>;
              return Card(
                margin: const EdgeInsets.only(bottom: 10),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor:
                    const Color(0xFF10B981).withOpacity(0.15),
                    child: Text(
                      (d['name'] ?? 'C')[0].toUpperCase(),
                      style: const TextStyle(
                          color: Color(0xFF10B981),
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                  title: Text(d['name'] ?? '',
                      style: const TextStyle(
                          fontWeight: FontWeight.w600)),
                  subtitle: Text(
                    '${d['phone']} • ${d['area']}',
                    style: const TextStyle(fontSize: 12),
                  ),
                  trailing: const Icon(Icons.chevron_right_rounded,
                      color: AppTheme.textGrey),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

// ─── Visits View ─────────────────────────────────────────────────────────────
class AdminVisitsView extends StatelessWidget {
  const AdminVisitsView({super.key});

  Color _outcomeColor(String outcome) {
    switch (outcome) {
      case 'Sold':
        return Colors.green;
      case 'Interested':
        return Colors.blue;
      case 'Follow Up':
        return Colors.orange;
      case 'Not Interested':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('All Visits')),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('visits')
            .orderBy('createdAt', descending: true)
            .snapshots(),
        builder: (ctx, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final docs = snap.data?.docs ?? [];
          if (docs.isEmpty) {
            return const Center(
                child: Text('No visits recorded.',
                    style: TextStyle(color: AppTheme.textGrey)));
          }
          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: docs.length,
            itemBuilder: (_, i) {
              final d = docs[i].data() as Map<String, dynamic>;
              final outcome = d['outcome'] ?? '';
              final color = _outcomeColor(outcome);

              return Card(
                margin: const EdgeInsets.only(bottom: 10),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: color.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Icon(Icons.directions_walk_rounded,
                            color: color, size: 22),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment:
                          CrossAxisAlignment.start,
                          children: [
                            Text(d['customerName'] ?? '',
                                style: const TextStyle(
                                    fontWeight: FontWeight.w600,
                                    fontSize: 13)),
                            if ((d['notes'] ?? '').isNotEmpty)
                              Text(d['notes'],
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                      fontSize: 12,
                                      color: AppTheme.textGrey)),
                            if (d['lat'] != null)
                              Row(
                                children: [
                                  const Icon(
                                      Icons.location_on_rounded,
                                      size: 12,
                                      color: Colors.grey),
                                  const SizedBox(width: 2),
                                  Text(
                                    '${d['lat']?.toStringAsFixed(4)}, ${d['lng']?.toStringAsFixed(4)}',
                                    style: const TextStyle(
                                        fontSize: 11,
                                        color: AppTheme.textGrey),
                                  ),
                                ],
                              ),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: color.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(outcome,
                            style: TextStyle(
                                color: color,
                                fontSize: 11,
                                fontWeight: FontWeight.w600)),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}