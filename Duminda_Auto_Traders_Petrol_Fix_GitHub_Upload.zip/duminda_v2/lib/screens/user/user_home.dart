import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../theme/app_theme.dart';
import '../login_screen.dart';
import 'attendance_screen.dart';
import 'petrol_screen.dart';
import 'customer_registration_screen.dart';
import 'customer_visits_screen.dart';

class UserHome extends StatefulWidget {
  const UserHome({super.key});

  @override
  State<UserHome> createState() => _UserHomeState();
}

class _UserHomeState extends State<UserHome> {
  String _userName = '';

  @override
  void initState() {
    super.initState();
    _loadUser();
  }

  Future<void> _loadUser() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid != null) {
      final doc = await FirebaseFirestore.instance
          .collection('users')
          .doc(uid)
          .get();
      setState(() {
        _userName = doc.data()?['name'] ?? 'User';
      });
    }
  }

  void _logout() async {
    await FirebaseAuth.instance.signOut();
    if (mounted) {
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (_) => const LoginScreen()));
    }
  }

  @override
  Widget build(BuildContext context) {
    final List<_HomeButton> buttons = [
      _HomeButton(
        icon: Icons.access_time_rounded,
        label: 'Attendance',
        subtitle: 'Check in & out',
        color: const Color(0xFF6366F1),
        screen: const AttendanceScreen(),
      ),
      _HomeButton(
        icon: Icons.local_gas_station_rounded,
        label: 'Petrol',
        subtitle: 'Log fuel expense',
        color: const Color(0xFFF59E0B),
        screen: const PetrolScreen(),
      ),
      _HomeButton(
        icon: Icons.person_add_rounded,
        label: 'Customer\nRegistration',
        subtitle: 'Add new customer',
        color: const Color(0xFF10B981),
        screen: const CustomerRegistrationScreen(),
      ),
      _HomeButton(
        icon: Icons.directions_walk_rounded,
        label: 'Customer\nVisits',
        subtitle: 'Log a visit',
        color: const Color(0xFFEF4444),
        screen: const CustomerVisitsScreen(),
      ),
    ];

    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        title: const Text('Sales Tracker'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout_rounded),
            onPressed: _logout,
            tooltip: 'Logout',
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [AppTheme.primary, AppTheme.secondary],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Row(
                  children: [
                    const CircleAvatar(
                      backgroundColor: Colors.white24,
                      radius: 26,
                      child: Icon(Icons.person_rounded,
                          color: Colors.white, size: 28),
                    ),
                    const SizedBox(width: 14),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Hello, $_userName 👋',
                          style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.white),
                        ),
                        const Text(
                          "Let's get things done today!",
                          style: TextStyle(
                              fontSize: 12, color: Colors.white70),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 28),
              const Text(
                'Quick Actions',
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: AppTheme.textDark),
              ),
              const SizedBox(height: 14),
              Expanded(
                child: GridView.count(
                  crossAxisCount: 2,
                  crossAxisSpacing: 14,
                  mainAxisSpacing: 14,
                  children: buttons
                      .map((btn) => _buildCard(context, btn))
                      .toList(),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCard(BuildContext context, _HomeButton btn) {
    return GestureDetector(
      onTap: () => Navigator.push(
          context, MaterialPageRoute(builder: (_) => btn.screen)),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: btn.color.withOpacity(0.15),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                color: btn.color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Icon(btn.icon, color: btn.color, size: 30),
            ),
            const SizedBox(height: 14),
            Text(
              btn.label,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontWeight: FontWeight.w700,
                fontSize: 14,
                color: AppTheme.textDark,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              btn.subtitle,
              style: const TextStyle(
                  fontSize: 11, color: AppTheme.textGrey),
            ),
          ],
        ),
      ),
    );
  }
}

class _HomeButton {
  final IconData icon;
  final String label;
  final String subtitle;
  final Color color;
  final Widget screen;

  _HomeButton({
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.color,
    required this.screen,
  });
}