import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../theme/app_theme.dart';

class CustomerRegistrationScreen extends StatefulWidget {
  const CustomerRegistrationScreen({super.key});

  @override
  State<CustomerRegistrationScreen> createState() =>
      _CustomerRegistrationScreenState();
}

class _CustomerRegistrationScreenState
    extends State<CustomerRegistrationScreen> {
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _addressController = TextEditingController();
  final _areaController = TextEditingController();
  final _notesController = TextEditingController();
  bool _loading = false;

  Future<void> _submit() async {
    if (_nameController.text.isEmpty ||
        _phoneController.text.isEmpty ||
        _areaController.text.isEmpty) {
      _showSnack('Name, phone and area are required', Colors.red);
      return;
    }

    setState(() => _loading = true);
    try {
      final uid = FirebaseAuth.instance.currentUser?.uid;
      await FirebaseFirestore.instance.collection('customers').add({
        'name': _nameController.text.trim(),
        'phone': _phoneController.text.trim(),
        'address': _addressController.text.trim(),
        'area': _areaController.text.trim(),
        'notes': _notesController.text.trim(),
        'registeredBy': uid,
        'createdAt': FieldValue.serverTimestamp(),
      });

      _nameController.clear();
      _phoneController.clear();
      _addressController.clear();
      _areaController.clear();
      _notesController.clear();

      _showSnack('Customer registered successfully ?? "" ✅', Colors.green);
    } catch (e) {
      _showSnack('Error: $e', Colors.red);
    } finally {
      setState(() => _loading = false);
    }
  }

  void _showSnack(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        shape:
        RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  Widget _field(
      String label,
      TextEditingController ctrl,
      IconData icon, {
        TextInputType type = TextInputType.text,
        int maxLines = 1,
        bool required = false,
      }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(children: [
          Text(label,
              style: const TextStyle(
                  fontSize: 13, fontWeight: FontWeight.w600)),
          if (required)
            const Text(' *', style: TextStyle(color: Colors.red)),
        ]),
        const SizedBox(height: 6),
        TextField(
          controller: ctrl,
          keyboardType: type,
          maxLines: maxLines,
          decoration: InputDecoration(
            prefixIcon: Icon(icon),
          ),
        ),
        const SizedBox(height: 16),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Customer Registration')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                    color: Colors.black.withOpacity(0.06),
                    blurRadius: 10,
                    offset: const Offset(0, 3))
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  children: [
                    Icon(Icons.person_add_rounded,
                        color: Color(0xFF10B981), size: 24),
                    SizedBox(width: 8),
                    Text('New Customer',
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            color: AppTheme.textDark)),
                  ],
                ),
                const Divider(height: 24),

                _field(
                  'Full Name',
                  _nameController,
                  Icons.person_outline,
                  required: true,
                ),
                _field(
                  'Phone Number',
                  _phoneController,
                  Icons.phone_outlined,
                  type: TextInputType.phone,
                  required: true,
                ),
                _field(
                  'Address',
                  _addressController,
                  Icons.home_outlined,
                  maxLines: 2,
                ),
                _field(
                  'Area / Zone',
                  _areaController,
                  Icons.location_city_rounded,
                  required: true,
                ),
                _field(
                  'Notes',
                  _notesController,
                  Icons.notes_rounded,
                  maxLines: 3,
                ),

                const SizedBox(height: 4),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton.icon(
                    onPressed: _loading ? null : _submit,
                    style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF10B981)),
                    icon: _loading
                        ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                            color: Colors.white, strokeWidth: 2))
                        : const Icon(Icons.save_rounded),
                    label: const Text('Register Customer'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}