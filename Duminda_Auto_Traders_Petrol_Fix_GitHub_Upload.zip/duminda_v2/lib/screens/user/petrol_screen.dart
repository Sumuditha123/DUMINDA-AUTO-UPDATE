import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';

import '../../theme/app_theme.dart';

/// IMPORTANT:
/// 1. Deploy the supplied Google Apps Script as a Web App.
/// 2. Paste the deployed /exec URL below.
/// 3. Use the same shared token in Code.gs and below.
const String petrolGoogleAppsScriptUrl = 'https://script.google.com/macros/s/AKfycbyB7EOPoakXGqL8atfohmli-M0_naUlAy07PWX_h8Km9SgDDqZznIT8NauFmICK6InDZQ/exec';
const String petrolUploadToken = 'DUMINDA_AUTO_TRADERS';

class PetrolScreen extends StatefulWidget {
  const PetrolScreen({super.key});

  @override
  State<PetrolScreen> createState() => _PetrolScreenState();
}

class _PetrolScreenState extends State<PetrolScreen> {
  final _stationController = TextEditingController();
  final _litresController = TextEditingController();
  final _photoLinkController = TextEditingController();
  final _remarksController = TextEditingController();

  // Keep the existing claim fields so the current Firebase Admin approval
  // screen continues to receive its expected data.
  final _amountController = TextEditingController();
  final _kmController = TextEditingController();

  bool _loading = false;
  List<Map<String, dynamic>> _history = [];

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  @override
  void dispose() {
    _stationController.dispose();
    _litresController.dispose();
    _photoLinkController.dispose();
    _remarksController.dispose();
    _amountController.dispose();
    _kmController.dispose();
    super.dispose();
  }

  Future<Map<String, dynamic>> _currentUserData() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) throw Exception('Please sign in again.');

    final doc = await FirebaseFirestore.instance
        .collection('users')
        .doc(user.uid)
        .get();
    final data = doc.data() ?? <String, dynamic>{};

    String firstNonEmpty(List<String> keys, String fallback) {
      for (final key in keys) {
        final value = data[key]?.toString().trim() ?? '';
        if (value.isNotEmpty) return value;
      }
      return fallback;
    }

    return {
      'uid': user.uid,
      'repNum': firstNonEmpty(
          ['repNum', 'repNumber', 'repId', 'employeeId', 'code'], user.uid),
      'repName': firstNonEmpty(['name', 'fullName', 'displayName'], user.email ?? 'Rep'),
    };
  }

  Future<void> _loadHistory() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;
      final query = await FirebaseFirestore.instance
          .collection('petrol')
          .where('userId', isEqualTo: user.uid)
          .orderBy('createdAt', descending: true)
          .limit(10)
          .get();
      if (!mounted) return;
      setState(() {
        _history = query.docs.map((d) => d.data()).toList();
      });
    } catch (_) {
      // History loading must not prevent a new petrol submission.
    }
  }

  Future<void> _submit() async {
    final station = _stationController.text.trim();
    final litres = double.tryParse(_litresController.text.trim());
    final photoLink = _photoLinkController.text.trim();
    final remarks = _remarksController.text.trim();
    final amount = double.tryParse(_amountController.text.trim()) ?? 0;
    final km = double.tryParse(_kmController.text.trim()) ?? 0;

    if (station.isEmpty || litres == null || litres <= 0) {
      _showSnack('Enter Petrol Station Name and valid Petrol (L).', Colors.red);
      return;
    }
    if (petrolGoogleAppsScriptUrl.startsWith('PASTE_') ||
        petrolUploadToken.startsWith('CHANGE_')) {
      _showSnack('Google Sheets setup is not complete. Ask admin to deploy the script.', Colors.red);
      return;
    }

    setState(() => _loading = true);
    try {
      final userData = await _currentUserData();
      final now = DateTime.now();
      final dateTime = DateFormat('yyyy-MM-dd HH:mm:ss').format(now);
      final sriLankaTime = DateFormat('yyyy-MM-dd HH:mm:ss')
          .format(now.toUtc().add(const Duration(hours: 5, minutes: 30)));

      // Save to Firestore as before, preserving the current Admin Petrol Claims
      // workflow and the old fields expected by that screen.
      await FirebaseFirestore.instance.collection('petrol').add({
        'userId': userData['uid'],
        'repNum': userData['repNum'],
        'repName': userData['repName'],
        'date': DateFormat('yyyy-MM-dd').format(now),
        'stationName': station,
        'litres': litres,
        'photoLink': photoLink,
        'amount': amount,
        'kmReading': km,
        'notes': remarks,
        'status': 'pending',
        'createdAt': FieldValue.serverTimestamp(),
      });

      final response = await http.post(
        Uri.parse(petrolGoogleAppsScriptUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'token': petrolUploadToken,
          'dateTime': dateTime,
          'repNum': userData['repNum'],
          'repName': userData['repName'],
          'stationName': station,
          'litres': litres,
          'photoLink': photoLink,
          'remarks': remarks,
          'sriLankaTime': sriLankaTime,
        }),
      ).timeout(const Duration(seconds: 30));

      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw Exception('Google Sheets response ${response.statusCode}. Firestore claim was saved; Sheets upload needs retry/admin check.');
      }
      Map<String, dynamic> result;
      try {
        result = jsonDecode(response.body) as Map<String, dynamic>;
      } catch (_) {
        throw Exception('Unexpected response from Google Sheets. Firestore claim was saved; ask admin to check Apps Script deployment.');
      }
      if (result['ok'] != true && result['status'] != 'success') {
        throw Exception('${result['error'] ?? result['message'] ?? 'Google Sheets rejected the record'}. Firestore claim was saved.');
      }

      _stationController.clear();
      _litresController.clear();
      _photoLinkController.clear();
      _remarksController.clear();
      _amountController.clear();
      _kmController.clear();
      await _loadHistory();
      if (mounted) _showSnack('Petrol record uploaded to Google Sheets successfully.', Colors.green);
    } catch (e) {
      if (mounted) _showSnack('Upload issue: $e', Colors.red);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _showSnack(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  Widget _field(String label, TextEditingController controller, {
    String? hint,
    TextInputType keyboard = TextInputType.text,
    int maxLines = 1,
    bool required = false,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('$label${required ? ' *' : ''}',
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
          const SizedBox(height: 6),
          TextField(
            controller: controller,
            keyboardType: keyboard,
            maxLines: maxLines,
            decoration: InputDecoration(hintText: hint),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Petrol Record')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [BoxShadow(
                    color: Colors.black.withOpacity(0.06),
                    blurRadius: 10,
                    offset: const Offset(0, 3),
                  )],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('New Petrol Record',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppTheme.textDark)),
                    const SizedBox(height: 18),
                    _field('Petrol Station Name', _stationController,
                        hint: 'e.g. Lanka Filling Station', required: true),
                    _field('Petrol (L)', _litresController,
                        hint: 'e.g. 10.5', keyboard: const TextInputType.numberWithOptions(decimal: true), required: true),
                    _field('Photo Link (Optional)', _photoLinkController,
                        hint: 'Paste uploaded receipt/photo URL'),
                    _field('Remarks (Optional)', _remarksController,
                        hint: 'Any additional details', maxLines: 2),
                    const Divider(height: 24),
                    const Text('Existing claim details (optional)',
                        style: TextStyle(fontWeight: FontWeight.w600, color: AppTheme.textGrey)),
                    const SizedBox(height: 12),
                    _field('Amount (LKR)', _amountController,
                        hint: 'e.g. 2500', keyboard: TextInputType.number),
                    _field('KM Reading', _kmController,
                        hint: 'e.g. 45230', keyboard: TextInputType.number),
                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton.icon(
                        onPressed: _loading ? null : _submit,
                        icon: _loading
                            ? const SizedBox(width: 18, height: 18,
                                child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                            : const Icon(Icons.cloud_upload_rounded),
                        label: Text(_loading ? 'Uploading...' : 'Submit Petrol Record'),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 28),
              const Text('Recent Entries',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppTheme.textDark)),
              const SizedBox(height: 12),
              if (_history.isEmpty)
                const Center(child: Text('No entries yet.', style: TextStyle(color: AppTheme.textGrey)))
              else
                ..._history.map((entry) => _HistoryTile(entry: entry)),
            ],
          ),
        ),
      ),
    );
  }
}

class _HistoryTile extends StatelessWidget {
  final Map<String, dynamic> entry;
  const _HistoryTile({required this.entry});

  @override
  Widget build(BuildContext context) {
    final status = entry['status'] ?? 'pending';
    final statusColor = status == 'approved'
        ? Colors.green
        : status == 'rejected' ? Colors.red : Colors.orange;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade100),
      ),
      child: Row(
        children: [
          const Icon(Icons.local_gas_station_rounded, color: Color(0xFFF59E0B), size: 24),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(entry['stationName']?.toString().isNotEmpty == true
                    ? entry['stationName'].toString()
                    : (entry['date'] ?? ''),
                    style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                Text('Petrol: ${entry['litres'] ?? '-'} L  |  KM: ${entry['kmReading'] ?? '-'}',
                    style: const TextStyle(fontSize: 12, color: AppTheme.textGrey)),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text('LKR ${entry['amount'] ?? 0}',
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
              Text(status.toString(), style: TextStyle(color: statusColor, fontSize: 11, fontWeight: FontWeight.w600)),
            ],
          ),
        ],
      ),
    );
  }
}
