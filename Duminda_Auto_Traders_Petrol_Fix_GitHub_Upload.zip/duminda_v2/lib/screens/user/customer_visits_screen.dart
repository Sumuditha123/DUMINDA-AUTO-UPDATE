import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geolocator/geolocator.dart';
import 'package:intl/intl.dart';
import '../../theme/app_theme.dart';

class CustomerVisitsScreen extends StatefulWidget {
  const CustomerVisitsScreen({super.key});

  @override
  State<CustomerVisitsScreen> createState() => _CustomerVisitsScreenState();
}

class _CustomerVisitsScreenState extends State<CustomerVisitsScreen> {
  final _notesController = TextEditingController();
  bool _loading = false;
  bool _fetchingCustomers = true;

  List<Map<String, dynamic>> _customers = [];
  Map<String, dynamic>? _selectedCustomer;
  String _outcome = 'Interested';
  List<Map<String, dynamic>> _recentVisits = [];

  final List<String> _outcomes = [
    'Interested',
    'Not Interested',
    'Follow Up',
    'Sold',
    'No Contact',
  ];

  @override
  void initState() {
    super.initState();
    _loadCustomers();
    _loadRecentVisits();
  }

  Future<void> _loadCustomers() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    final query = await FirebaseFirestore.instance
        .collection('customers')
        .where('registeredBy', isEqualTo: uid)
        .orderBy('createdAt', descending: true)
        .get();

    setState(() {
      _customers =
          query.docs.map((d) => {'id': d.id, ...d.data()}).toList();
      _fetchingCustomers = false;
    });
  }

  Future<void> _loadRecentVisits() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    final query = await FirebaseFirestore.instance
        .collection('visits')
        .where('userId', isEqualTo: uid)
        .orderBy('createdAt', descending: true)
        .limit(5)
        .get();

    setState(() {
      _recentVisits = query.docs.map((d) => d.data()).toList();
    });
  }

  Future<Position?> _getLocation() async {
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) return null;
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) return null;
      }
      return await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high);
    } catch (_) {
      return null;
    }
  }

  Future<void> _submit() async {
    if (_selectedCustomer == null) {
      _showSnack('Please select a customer', Colors.red);
      return;
    }

    setState(() => _loading = true);
    try {
      final position = await _getLocation();
      final uid = FirebaseAuth.instance.currentUser?.uid;

      await FirebaseFirestore.instance.collection('visits').add({
        'userId': uid,
        'customerId': _selectedCustomer!['id'],
        'customerName': _selectedCustomer!['name'],
        'notes': _notesController.text.trim(),
        'outcome': _outcome,
        'lat': position?.latitude,
        'lng': position?.longitude,
        'visitedAt': DateTime.now().toIso8601String(),
        'createdAt': FieldValue.serverTimestamp(),
      });

      _notesController.clear();
      setState(() {
        _selectedCustomer = null;
        _outcome = 'Interested';
      });
      _showSnack('Visit logged successfully ?? "" 📍', Colors.green);
      _loadRecentVisits();
    } catch (e) {
      _showSnack('Error: $e', Colors.red);
    } finally {
      setState(() => _loading = false);
    }
  }

  void _showSnack(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        shape:
        RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  Color _outcomeColor(String outcome) {
    switch (outcome) {
      case 'Sold':
        return Colors.green;
      case 'Interested':
        return Colors.blue;
      case 'Follow Up':
        return Colors.orange;
      case 'Not Interested':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Customer Visits')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black.withOpacity(0.06),
                        blurRadius: 10,
                        offset: const Offset(0, 3))
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Row(
                      children: [
                        Icon(Icons.directions_walk_rounded,
                            color: Color(0xFFEF4444), size: 24),
                        SizedBox(width: 8),
                        Text('Log New Visit',
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                                color: AppTheme.textDark)),
                      ],
                    ),
                    const Divider(height: 24),

                    const Text('Select Customer *',
                        style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w600)),
                    const SizedBox(height: 6),
                    _fetchingCustomers
                        ? const Center(
                        child: CircularProgressIndicator())
                        : DropdownButtonFormField<Map<String, dynamic>>(
                      value: _selectedCustomer,
                      hint: const Text('Choose customer'),
                      decoration: InputDecoration(
                        border: OutlineInputBorder(
                            borderRadius:
                            BorderRadius.circular(12)),
                        contentPadding:
                        const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 12),
                      ),
                      items: _customers
                          .map((c) => DropdownMenuItem(
                          value: c,
                          child: Text(
                              '${c['name']} - ${c['area']}',
                              overflow:
                              TextOverflow.ellipsis)))
                          .toList(),
                      onChanged: (val) => setState(
                              () => _selectedCustomer = val),
                    ),
                    const SizedBox(height: 16),

                    const Text('Outcome',
                        style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w600)),
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 8,
                      children: _outcomes
                          .map((o) => ChoiceChip(
                        label: Text(o),
                        selected: _outcome == o,
                        onSelected: (_) =>
                            setState(() => _outcome = o),
                        selectedColor: _outcomeColor(o)
                            .withOpacity(0.2),
                        labelStyle: TextStyle(
                            color: _outcome == o
                                ? _outcomeColor(o)
                                : Colors.grey,
                            fontWeight: FontWeight.w600),
                      ))
                          .toList(),
                    ),
                    const SizedBox(height: 16),

                    const Text('Notes',
                        style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w600)),
                    const SizedBox(height: 6),
                    TextField(
                      controller: _notesController,
                      maxLines: 3,
                      decoration: const InputDecoration(
                        hintText: 'Visit notes...',
                        prefixIcon: Icon(Icons.notes_rounded),
                      ),
                    ),
                    const SizedBox(height: 20),

                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton.icon(
                        onPressed: _loading ? null : _submit,
                        style: ElevatedButton.styleFrom(
                            backgroundColor:
                            const Color(0xFFEF4444)),
                        icon: _loading
                            ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                                color: Colors.white,
                                strokeWidth: 2))
                            : const Icon(
                            Icons.add_location_alt_rounded),
                        label: const Text('Log Visit'),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              const Text('Recent Visits',
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: AppTheme.textDark)),
              const SizedBox(height: 12),

              if (_recentVisits.isEmpty)
                const Center(
                    child: Text('No visits yet.',
                        style: TextStyle(color: AppTheme.textGrey)))
              else
                ..._recentVisits.map((v) {
                  final outcome = v['outcome'] ?? '';
                  final color = _outcomeColor(outcome);
                  final visitedAt = v['visitedAt'] != null
                      ? DateFormat('MMM d, hh:mm a')
                      .format(DateTime.parse(v['visitedAt']))
                      : '';
                  return Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      border:
                      Border.all(color: Colors.grey.shade100),
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: color.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Icon(
                              Icons.directions_walk_rounded,
                              color: color,
                              size: 20),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment:
                            CrossAxisAlignment.start,
                            children: [
                              Text(v['customerName'] ?? '',
                                  style: const TextStyle(
                                      fontWeight: FontWeight.w600,
                                      fontSize: 13)),
                              Text(visitedAt,
                                  style: const TextStyle(
                                      fontSize: 11,
                                      color: AppTheme.textGrey)),
                            ],
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            color: color.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(outcome,
                              style: TextStyle(
                                  color: color,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600)),
                        ),
                      ],
                    ),
                  );
                }),
            ],
          ),
        ),
      ),
    );
  }
}