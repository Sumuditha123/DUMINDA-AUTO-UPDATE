import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geolocator/geolocator.dart';
import 'package:intl/intl.dart';
import '../../theme/app_theme.dart';

class AttendanceScreen extends StatefulWidget {
  const AttendanceScreen({super.key});

  @override
  State<AttendanceScreen> createState() => _AttendanceScreenState();
}

class _AttendanceScreenState extends State<AttendanceScreen> {
  bool _loading = false;
  Map<String, dynamic>? _todayRecord;
  final String _today = DateFormat('yyyy-MM-dd').format(DateTime.now());

  @override
  void initState() {
    super.initState();
    _loadTodayRecord();
  }

  Future<void> _loadTodayRecord() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    final query = await FirebaseFirestore.instance
        .collection('attendance')
        .where('userId', isEqualTo: uid)
        .where('date', isEqualTo: _today)
        .limit(1)
        .get();

    if (query.docs.isNotEmpty) {
      setState(() => _todayRecord = {
        ...query.docs.first.data(),
        'docId': query.docs.first.id,
      });
    }
  }

  Future<Position> _getLocation() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) throw 'Location services are disabled.';

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        throw 'Location permission denied.';
      }
    }
    if (permission == LocationPermission.deniedForever) {
      throw 'Location permissions are permanently denied.';
    }

    return await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
  }

  Future<void> _checkIn() async {
    setState(() => _loading = true);
    try {
      final position = await _getLocation();
      final uid = FirebaseAuth.instance.currentUser?.uid;
      final now = DateTime.now();

      final docRef = await FirebaseFirestore.instance
          .collection('attendance')
          .add({
        'userId': uid,
        'date': _today,
        'checkIn': {
          'time': now.toIso8601String(),
          'lat': position.latitude,
          'lng': position.longitude,
        },
        'checkOut': null,
        'createdAt': FieldValue.serverTimestamp(),
      });

      setState(() => _todayRecord = {
        'userId': uid,
        'date': _today,
        'checkIn': {
          'time': now.toIso8601String(),
          'lat': position.latitude,
          'lng': position.longitude,
        },
        'checkOut': null,
        'docId': docRef.id,
      });

      _showSnack('Checked in successfully ?? "" ✅', Colors.green);
    } catch (e) {
      _showSnack('Error: $e', Colors.red);
    } finally {
      setState(() => _loading = false);
    }
  }

  Future<void> _checkOut() async {
    setState(() => _loading = true);
    try {
      final position = await _getLocation();
      final now = DateTime.now();
      final docId = _todayRecord!['docId'];

      final checkOutData = {
        'time': now.toIso8601String(),
        'lat': position.latitude,
        'lng': position.longitude,
      };

      await FirebaseFirestore.instance
          .collection('attendance')
          .doc(docId)
          .update({'checkOut': checkOutData});

      setState(() => _todayRecord!['checkOut'] = checkOutData);
      _showSnack('Checked out successfully ?? "" 👋', Colors.blue);
    } catch (e) {
      _showSnack('Error: $e', Colors.red);
    } finally {
      setState(() => _loading = false);
    }
  }

  void _showSnack(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        shape:
        RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  String _formatTime(String? isoTime) {
    if (isoTime == null) return '--';
    return DateFormat('hh:mm a').format(DateTime.parse(isoTime));
  }

  @override
  Widget build(BuildContext context) {
    final hasCheckedIn = _todayRecord != null;
    final hasCheckedOut =
        hasCheckedIn && _todayRecord!['checkOut'] != null;

    return Scaffold(
      appBar: AppBar(title: const Text('Attendance')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: const Color(0xFF6366F1),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Column(
                  children: [
                    const Icon(Icons.calendar_today_rounded,
                        color: Colors.white, size: 32),
                    const SizedBox(height: 8),
                    Text(
                      DateFormat('EEEE, MMMM d, yyyy')
                          .format(DateTime.now()),
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              Row(
                children: [
                  Expanded(
                    child: _TimeCard(
                      label: 'Check In',
                      time: hasCheckedIn
                          ? _formatTime(
                          _todayRecord!['checkIn']['time'])
                          : '--:--',
                      icon: Icons.login_rounded,
                      color: Colors.green,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _TimeCard(
                      label: 'Check Out',
                      time: hasCheckedOut
                          ? _formatTime(
                          _todayRecord!['checkOut']['time'])
                          : '--:--',
                      icon: Icons.logout_rounded,
                      color: Colors.orange,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),

              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.blue.shade50,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.blue.shade100),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.location_on_rounded,
                        color: Colors.blue, size: 20),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Your GPS location will be recorded automatically when you check in/out.',
                        style: TextStyle(
                            fontSize: 12, color: Colors.blueGrey),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 32),

              SizedBox(
                width: double.infinity,
                height: 54,
                child: ElevatedButton.icon(
                  onPressed: _loading
                      ? null
                      : hasCheckedOut
                      ? null
                      : hasCheckedIn
                      ? _checkOut
                      : _checkIn,
                  style: ElevatedButton.styleFrom(
                    backgroundColor:
                    hasCheckedIn && !hasCheckedOut
                        ? Colors.orange
                        : hasCheckedOut
                        ? Colors.grey
                        : Colors.green,
                  ),
                  icon: _loading
                      ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                          color: Colors.white, strokeWidth: 2))
                      : Icon(hasCheckedIn && !hasCheckedOut
                      ? Icons.logout_rounded
                      : Icons.login_rounded),
                  label: Text(
                    hasCheckedOut
                        ? 'Attendance Completed'
                        : hasCheckedIn
                        ? 'Check Out'
                        : 'Check In',
                    style: const TextStyle(fontSize: 16),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TimeCard extends StatelessWidget {
  final String label;
  final String time;
  final IconData icon;
  final Color color;

  const _TimeCard({
    required this.label,
    required this.time,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.15),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 28),
          const SizedBox(height: 8),
          Text(label,
              style: const TextStyle(
                  fontSize: 12, color: AppTheme.textGrey)),
          const SizedBox(height: 4),
          Text(time,
              style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: color)),
        ],
      ),
    );
  }
}